<?php
// Fungsi autentikasi bersama untuk halaman website RTS Panel.
// File ini tidak melakukan login; login akan menggunakan username.

if (session_status() !== PHP_SESSION_ACTIVE) {
    session_start();
}

function rts_is_logged_in(): bool
{
    return !empty($_SESSION['is_logged_in']) && $_SESSION['is_logged_in'] === true;
}

function rts_current_role(): string
{
    return strtoupper((string)($_SESSION['role'] ?? ''));
}

function rts_require_login(): void
{
    if (!rts_is_logged_in()) {
        header('Location: dashboard.php');
        exit;
    }
}

function rts_is_admin(): bool
{
    return rts_current_role() === 'ADMIN';
}

function rts_is_approver(): bool
{
    return in_array(rts_current_role(), ['ADMIN', 'ASS'], true);
}

function rts_has_all_district_access(): bool
{
    return in_array(rts_current_role(), ['ADMIN', 'ASS', 'WSS', 'SMST'], true);
}

function rts_can_see_all_customers(): bool
{
    return rts_has_all_district_access();
}

function rts_current_username(): string
{
    return (string)($_SESSION['username'] ?? '');
}

function rts_current_salesman(): string
{
    return trim((string)($_SESSION['salesman'] ?? ''));
}

function rts_current_district(): string
{
    return trim((string)($_SESSION['sales_district'] ?? ''));
}

function rts_notify_email(mysqli $conn, string $email, string $title, string $message, string $type = 'INFO', ?string $reference_type = null, ?int $reference_id = null): bool
{
    if ($email === '') return false;
    $stmt = $conn->prepare('INSERT INTO notifications (recipient_email, title, message, type, reference_type, reference_id) VALUES (?, ?, ?, ?, ?, ?)');
    if (!$stmt) return false;
    $stmt->bind_param('sssssi', $email, $title, $message, $type, $reference_type, $reference_id);
    return $stmt->execute();
}
