<?php
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/auth.php';
rts_require_login();
if (!rts_is_approver()) { http_response_code(403); exit('Akses hanya untuk ADMIN atau ASS.'); }
$id = trim($_GET['id'] ?? $_POST['id_customer'] ?? '');
$message = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nama = trim($_POST['nama_toko'] ?? '');
    $tipe = strtoupper(trim($_POST['tipe_customer'] ?? 'REGULER'));
    $alamat = trim($_POST['alamat'] ?? '');
    $salesman = trim($_POST['salesman'] ?? '');
    $district = trim($_POST['sales_district'] ?? '');
    $kunjungan = trim($_POST['kunjungan'] ?? '');
    $hari = trim($_POST['hari'] ?? '');
    $lat = trim($_POST['latitude'] ?? '');
    $lng = trim($_POST['longitude'] ?? '');
    $aktif = trim($_POST['status_aktif'] ?? 'Aktif');
    if ($nama === '' || !in_array($tipe, ['REGULER', 'GSP'], true)) $message = 'Nama toko dan tipe customer wajib benar.';
    else {
        $stmt = $conn->prepare('UPDATE master_toko SET nama_toko=?, tipe_customer=?, salesman=?, alamat=?, kunjungan=?, hari=?, sales_district=?, latitude=?, longitude=?, status_aktif=? WHERE id_customer=?');
        $stmt->bind_param('sssssssssss', $nama, $tipe, $salesman, $alamat, $kunjungan, $hari, $district, $lat, $lng, $aktif, $id);
        if ($stmt->execute()) { header('Location: master_customer.php?updated=1'); exit; }
        $message = 'Data gagal diperbarui.';
    }
}
$stmt = $conn->prepare('SELECT * FROM master_toko WHERE id_customer=? LIMIT 1');
$stmt->bind_param('s', $id); $stmt->execute(); $customer = $stmt->get_result()->fetch_assoc();
if (!$customer) { http_response_code(404); exit('Customer tidak ditemukan.'); }
function e($v) { return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); }
?><!doctype html><html lang="id"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>Edit Customer</title><link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet"></head><body class="bg-light"><main class="container py-4" style="max-width:900px"><a href="master_customer.php" class="text-decoration-none">← Kembali ke Master Customer</a><div class="card border-0 shadow-sm mt-3"><div class="card-body p-4"><h3>Edit Customer</h3><p class="text-muted">ID Customer: <strong><?= e($customer['id_customer']) ?></strong></p><?php if ($message): ?><div class="alert alert-danger"><?= e($message) ?></div><?php endif; ?><form method="post"><input type="hidden" name="id_customer" value="<?= e($customer['id_customer']) ?>"><div class="row g-3"><div class="col-md-8"><label class="form-label">Nama Toko</label><input name="nama_toko" class="form-control" value="<?= e($customer['nama_toko']) ?>" required></div><div class="col-md-4"><label class="form-label">Tipe Customer</label><select name="tipe_customer" class="form-select"><option <?= $customer['tipe_customer']==='REGULER'?'selected':'' ?>>REGULER</option><option <?= $customer['tipe_customer']==='GSP'?'selected':'' ?>>GSP</option></select></div><div class="col-12"><label class="form-label">Alamat</label><textarea name="alamat" class="form-control"><?= e($customer['alamat']) ?></textarea></div><div class="col-md-6"><label class="form-label">Salesman</label><input name="salesman" class="form-control" value="<?= e($customer['salesman']) ?>"></div><div class="col-md-6"><label class="form-label">Sales District</label><input name="sales_district" class="form-control" value="<?= e($customer['sales_district']) ?>"></div><div class="col-md-4"><label class="form-label">Kunjungan</label><input name="kunjungan" class="form-control" value="<?= e($customer['kunjungan']) ?>"></div><div class="col-md-4"><label class="form-label">Hari</label><input name="hari" class="form-control" value="<?= e($customer['hari']) ?>"></div><div class="col-md-4"><label class="form-label">Status</label><select name="status_aktif" class="form-select"><option <?= $customer['status_aktif']==='Aktif'?'selected':'' ?>>Aktif</option><option <?= $customer['status_aktif']==='Nonaktif'?'selected':'' ?>>Nonaktif</option></select></div><div class="col-md-6"><label class="form-label">Latitude</label><input name="latitude" class="form-control" value="<?= e($customer['latitude']) ?>"></div><div class="col-md-6"><label class="form-label">Longitude</label><input name="longitude" class="form-control" value="<?= e($customer['longitude']) ?>"></div></div><div class="mt-4 d-flex gap-2"><a href="master_customer.php" class="btn btn-outline-secondary">Batal</a><button class="btn btn-primary">Simpan Perubahan</button></div></form></div></div></main></body></html>
