<?php
require_once __DIR__ . '/../config.php';
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');
if ($_SERVER['REQUEST_METHOD'] !== 'POST') { http_response_code(405); echo json_encode(['success'=>false,'message'=>'Method tidak diizinkan']); exit; }
$body = json_decode(file_get_contents('php://input'), true) ?: $_POST;
$username = trim((string)($body['username'] ?? ''));
$password = (string)($body['password'] ?? '');
$device = trim((string)($body['device_name'] ?? 'Android'));
$stmt = $conn->prepare('SELECT id, username, nama_lengkap, email, password, role, salesman, sales_district, status_aktif FROM sales_users WHERE username=? LIMIT 1');
$stmt->bind_param('s', $username); $stmt->execute(); $user = $stmt->get_result()->fetch_assoc();
if (!$user || !password_verify($password, $user['password']) || ($user['status_aktif'] ?? 'Aktif') !== 'Aktif') { http_response_code(401); echo json_encode(['success'=>false,'message'=>'Username atau password salah']); exit; }
$plain = bin2hex(random_bytes(32)); $hash = hash('sha256', $plain); $expires = date('Y-m-d H:i:s', strtotime('+30 days'));
$save = $conn->prepare('INSERT INTO api_tokens (user_id, token_hash, device_name, expires_at) VALUES (?, ?, ?, ?)');
$save->bind_param('isss', $user['id'], $hash, $device, $expires); $save->execute();
echo json_encode(['success'=>true,'token'=>$plain,'expires_at'=>$expires,'user'=>['id'=>$user['id'],'username'=>$user['username'],'name'=>$user['nama_lengkap'],'role'=>strtoupper($user['role']),'salesman'=>$user['salesman'],'sales_district'=>$user['sales_district']]], JSON_UNESCAPED_UNICODE);
