<?php
require_once __DIR__ . '/auth.php';
if ($_SERVER['REQUEST_METHOD'] !== 'POST') api_fail('Method tidak diizinkan.',405);
$body = $_POST ?: (json_decode(file_get_contents('php://input'), true) ?: []);
$jenis = strtoupper(trim((string)($body['jenis_request'] ?? 'PENAMBAHAN')));
if (!in_array($jenis, ['PENAMBAHAN','PENGHAPUSAN'], true)) api_fail('Jenis GSP tidak valid.',400);
$required = ['toko_lama_nama','toko_lama_id','toko_baru_nama','toko_baru_id','alamat_lengkap','pic_nama','nomor_hp','koordinat'];
foreach ($required as $field) if (trim((string)($body[$field] ?? '')) === '') api_fail("Field $field wajib diisi.",400);
$district=$api_user['sales_district']??''; $salesman=$api_user['salesman']??$api_user['nama_lengkap']; $email=$api_user['email']; $role=strtoupper($api_user['role']);
$uploadDir = dirname(__DIR__) . '/uploads/gsp';
if (!is_dir($uploadDir)) mkdir($uploadDir, 0750, true);
function save_gsp_photo(string $key, string $dir): string {
    if (empty($_FILES[$key]) || $_FILES[$key]['error'] === UPLOAD_ERR_NO_FILE) return '';
    if ($_FILES[$key]['error'] !== UPLOAD_ERR_OK || $_FILES[$key]['size'] > 5 * 1024 * 1024) api_fail('Foto tidak valid atau lebih dari 5 MB.', 400);
    $allowed = ['image/jpeg'=>'jpg', 'image/png'=>'png'];
    $mime = (new finfo(FILEINFO_MIME_TYPE))->file($_FILES[$key]['tmp_name']);
    if (!isset($allowed[$mime])) api_fail('Foto harus JPG atau PNG.', 400);
    $name = bin2hex(random_bytes(16)) . '.' . $allowed[$mime];
    if (!move_uploaded_file($_FILES[$key]['tmp_name'], $dir . '/' . $name)) api_fail('Foto gagal disimpan.', 500);
    return 'uploads/gsp/' . $name;
}
$fktp=save_gsp_photo('foto_ktp',$uploadDir); $fluar=save_gsp_photo('foto_luar',$uploadDir); $fdalam=save_gsp_photo('foto_dalam',$uploadDir);
$stmt=$conn->prepare('INSERT INTO pengajuan_gsp (jenis_request,sales_email,sales_district,salesman,role,toko_lama_nama,toko_lama_id,toko_baru_nama,toko_baru_id,alamat_lengkap,pic_nama,nomor_hp,koordinat,link_foto_ktp,link_foto_luar,link_foto_dalam,status_approval) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?, ?,"Pending")');
$stmt->bind_param('ssssssssssssssss',$jenis,$email,$district,$salesman,$role,$body['toko_lama_nama'],$body['toko_lama_id'],$body['toko_baru_nama'],$body['toko_baru_id'],$body['alamat_lengkap'],$body['pic_nama'],$body['nomor_hp'],$body['koordinat'],$fktp,$fluar,$fdalam);
if(!$stmt->execute()) api_fail('Pengajuan GSP gagal disimpan.',500);
echo json_encode(['success'=>true,'message'=>'Pengajuan GSP berhasil dikirim.','id'=>$stmt->insert_id],JSON_UNESCAPED_UNICODE);
