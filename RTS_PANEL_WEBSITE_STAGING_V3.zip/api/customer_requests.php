<?php
require_once __DIR__ . '/auth.php';
if ($_SERVER['REQUEST_METHOD'] !== 'POST') api_fail('Method tidak diizinkan.',405);
$body=json_decode(file_get_contents('php://input'),true) ?: $_POST;
$allowed=['Tambah Baru','Tambah Outlet','Ganti Nama','Ganti Alamat','Hapus Toko'];
$jenis=trim((string)($body['jenis_request']??'')); if(!in_array($jenis,$allowed,true)) api_fail('Jenis pengajuan tidak valid.',400);
$id=trim((string)($body['id_customer']??'')); $oldName=trim((string)($body['nama_toko_lama']??'')); $newName=trim((string)($body['nama_toko_baru']??'')); $oldAddress=trim((string)($body['alamat_lama']??'')); $newAddress=trim((string)($body['alamat_baru']??''));
$stmt=$conn->prepare('INSERT INTO pengajuan_sales (sales_email,sales_distric,salesman,role,jenis_request,id_customer,pic,rute_kunjungan,week,nama_toko_lama,nama_toko_baru,alamat_lama,alamat_baru,tipe_baru,visit_day_baru,alasan,status_approval) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,"Pending")');
$role=strtoupper($api_user['role']); $district=$api_user['sales_district']??''; $salesman=$api_user['salesman']??$api_user['nama_lengkap']; $pic=trim((string)($body['pic']??'')); $route=trim((string)($body['rute_kunjungan']??'')); $week=trim((string)($body['week']??'')); $type=strtoupper(trim((string)($body['tipe_baru']??'REGULER'))); $visit=trim((string)($body['visit_day_baru']??'')); $reason=trim((string)($body['alasan']??''));
$stmt->bind_param('sssssssssssssssss',$api_user['email'],$district,$salesman,$role,$jenis,$id,$pic,$route,$week,$oldName,$newName,$oldAddress,$newAddress,$type,$visit,$reason); if(!$stmt->execute()) api_fail('Pengajuan gagal disimpan.',500);
echo json_encode(['success'=>true,'message'=>'Pengajuan berhasil dikirim.','id'=>$stmt->insert_id],JSON_UNESCAPED_UNICODE);
