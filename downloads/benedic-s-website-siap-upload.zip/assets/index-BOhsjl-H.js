(function(){const a=document.createElement("link").relList;if(a&&a.supports&&a.supports("modulepreload"))return;for(const n of document.querySelectorAll('link[rel="modulepreload"]'))r(n);new MutationObserver(n=>{for(const s of n)if(s.type==="childList")for(const o of s.addedNodes)o.tagName==="LINK"&&o.rel==="modulepreload"&&r(o)}).observe(document,{childList:!0,subtree:!0});function t(n){const s={};return n.integrity&&(s.integrity=n.integrity),n.referrerPolicy&&(s.referrerPolicy=n.referrerPolicy),n.crossOrigin==="use-credentials"?s.credentials="include":n.crossOrigin==="anonymous"?s.credentials="omit":s.credentials="same-origin",s}function r(n){if(n.ep)return;n.ep=!0;const s=t(n);fetch(n.href,s)}})();/**
 * @license lucide v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const y=(e,a,t=[])=>{const r=document.createElementNS("http://www.w3.org/2000/svg",e);return Object.keys(a).forEach(n=>{r.setAttribute(n,String(a[n]))}),t.length&&t.forEach(n=>{const s=y(...n);r.appendChild(s)}),r};var x=([e,a,t])=>y(e,a,t);/**
 * @license lucide v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const L=e=>Array.from(e.attributes).reduce((a,t)=>(a[t.name]=t.value,a),{}),E=e=>typeof e=="string"?e:!e||!e.class?"":e.class&&typeof e.class=="string"?e.class.split(" "):e.class&&Array.isArray(e.class)?e.class:"",C=e=>e.flatMap(E).map(t=>t.trim()).filter(Boolean).filter((t,r,n)=>n.indexOf(t)===r).join(" "),j=e=>e.replace(/(\w)(\w*)(_|-|\s*)/g,(a,t,r)=>t.toUpperCase()+r.toLowerCase()),h=(e,{nameAttr:a,icons:t,attrs:r})=>{var m;const n=e.getAttribute(a);if(n==null)return;const s=j(n),o=t[s];if(!o)return console.warn(`${e.outerHTML} icon name was not found in the provided icons object.`);const p=L(e),[b,w,S]=o,u={...w,"data-lucide":n,...r,...p},g=C(["lucide",`lucide-${n}`,p,r]);g&&Object.assign(u,{class:g});const A=x([b,u,S]);return(m=e.parentNode)==null?void 0:m.replaceChild(A,e)};/**
 * @license lucide v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const i={xmlns:"http://www.w3.org/2000/svg",width:24,height:24,viewBox:"0 0 24 24",fill:"none",stroke:"currentColor","stroke-width":2,"stroke-linecap":"round","stroke-linejoin":"round"};/**
 * @license lucide v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const T=["svg",i,[["path",{d:"M7 7h10v10"}],["path",{d:"M7 17 17 7"}]]];/**
 * @license lucide v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const $=["svg",i,[["path",{d:"m5 12 7-7 7 7"}],["path",{d:"M12 19V5"}]]];/**
 * @license lucide v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const N=["svg",i,[["path",{d:"M12 16v5"}],["path",{d:"M16 14v7"}],["path",{d:"M20 10v11"}],["path",{d:"m22 3-8.646 8.646a.5.5 0 0 1-.708 0L9.354 8.354a.5.5 0 0 0-.707 0L2 15"}],["path",{d:"M4 18v3"}],["path",{d:"M8 14v7"}]]];/**
 * @license lucide v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const O=["svg",i,[["path",{d:"m6 9 6 6 6-6"}]]];/**
 * @license lucide v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const q=["svg",i,[["path",{d:"M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"}],["polyline",{points:"7 10 12 15 17 10"}],["line",{x1:"12",x2:"12",y1:"15",y2:"3"}]]];/**
 * @license lucide v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const P=["svg",i,[["path",{d:"M4 22h14a2 2 0 0 0 2-2V7l-5-5H6a2 2 0 0 0-2 2v4"}],["path",{d:"M14 2v4a2 2 0 0 0 2 2h4"}],["path",{d:"m3 15 2 2 4-4"}]]];/**
 * @license lucide v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const I=["svg",i,[["path",{d:"M21.42 10.922a1 1 0 0 0-.019-1.838L12.83 5.18a2 2 0 0 0-1.66 0L2.6 9.08a1 1 0 0 0 0 1.832l8.57 3.908a2 2 0 0 0 1.66 0z"}],["path",{d:"M22 10v6"}],["path",{d:"M6 12.5V16a6 3 0 0 0 12 0v-3.5"}]]];/**
 * @license lucide v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const H=["svg",i,[["path",{d:"m11 17 2 2a1 1 0 1 0 3-3"}],["path",{d:"m14 14 2.5 2.5a1 1 0 1 0 3-3l-3.88-3.88a3 3 0 0 0-4.24 0l-.88.88a1 1 0 1 1-3-3l2.81-2.81a5.79 5.79 0 0 1 7.06-.87l.47.28a2 2 0 0 0 1.42.25L21 4"}],["path",{d:"m21 3 1 11h-2"}],["path",{d:"M3 3 2 14l6.5 6.5a1 1 0 1 0 3-3"}],["path",{d:"M3 4h8"}]]];/**
 * @license lucide v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const R=["svg",i,[["path",{d:"M16 8a6 6 0 0 1 6 6v7h-4v-7a2 2 0 0 0-2-2 2 2 0 0 0-2 2v7h-4v-7a6 6 0 0 1 6-6z"}],["rect",{width:"4",height:"12",x:"2",y:"9"}],["circle",{cx:"4",cy:"4",r:"2"}]]];/**
 * @license lucide v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const B=["svg",i,[["rect",{width:"20",height:"16",x:"2",y:"4",rx:"2"}],["path",{d:"m22 7-8.97 5.7a1.94 1.94 0 0 1-2.06 0L2 7"}]]];/**
 * @license lucide v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const V=["svg",i,[["path",{d:"M20 10c0 4.993-5.539 10.193-7.399 11.799a1 1 0 0 1-1.202 0C9.539 20.193 4 14.993 4 10a8 8 0 0 1 16 0"}],["circle",{cx:"12",cy:"10",r:"3"}]]];/**
 * @license lucide v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const U=["svg",i,[["line",{x1:"4",x2:"20",y1:"12",y2:"12"}],["line",{x1:"4",x2:"20",y1:"6",y2:"6"}],["line",{x1:"4",x2:"20",y1:"18",y2:"18"}]]];/**
 * @license lucide v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const z=["svg",i,[["path",{d:"M7.9 20A9 9 0 1 0 4 16.1L2 22Z"}]]];/**
 * @license lucide v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const D=["svg",i,[["path",{d:"M14 9a2 2 0 0 1-2 2H6l-4 4V4a2 2 0 0 1 2-2h8a2 2 0 0 1 2 2z"}],["path",{d:"M18 9h2a2 2 0 0 1 2 2v11l-4-4h-6a2 2 0 0 1-2-2v-1"}]]];/**
 * @license lucide v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const F=["svg",i,[["path",{d:"M12 17v4"}],["path",{d:"m15.2 4.9-.9-.4"}],["path",{d:"m15.2 7.1-.9.4"}],["path",{d:"m16.9 3.2-.4-.9"}],["path",{d:"m16.9 8.8-.4.9"}],["path",{d:"m19.5 2.3-.4.9"}],["path",{d:"m19.5 9.7-.4-.9"}],["path",{d:"m21.7 4.5-.9.4"}],["path",{d:"m21.7 7.5-.9-.4"}],["path",{d:"M22 13v2a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h7"}],["path",{d:"M8 21h8"}],["circle",{cx:"18",cy:"6",r:"3"}]]];/**
 * @license lucide v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const G=["svg",i,[["path",{d:"M9.937 15.5A2 2 0 0 0 8.5 14.063l-6.135-1.582a.5.5 0 0 1 0-.962L8.5 9.936A2 2 0 0 0 9.937 8.5l1.582-6.135a.5.5 0 0 1 .963 0L14.063 8.5A2 2 0 0 0 15.5 9.937l6.135 1.581a.5.5 0 0 1 0 .964L15.5 14.063a2 2 0 0 0-1.437 1.437l-1.582 6.135a.5.5 0 0 1-.963 0z"}],["path",{d:"M20 3v4"}],["path",{d:"M22 5h-4"}],["path",{d:"M4 17v2"}],["path",{d:"M5 18H3"}]]];/**
 * @license lucide v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const J=["svg",i,[["polyline",{points:"22 7 13.5 15.5 8.5 10.5 2 17"}],["polyline",{points:"16 7 22 7 22 13"}]]];/**
 * @license lucide v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const K=["svg",i,[["path",{d:"M18 21a8 8 0 0 0-16 0"}],["circle",{cx:"10",cy:"8",r:"5"}],["path",{d:"M22 20c0-3.37-2-6.5-4-8a5 5 0 0 0-.45-8.3"}]]];/**
 * @license lucide v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const W=["svg",i,[["path",{d:"M18 6 6 18"}],["path",{d:"m6 6 12 12"}]]];/**
 * @license lucide v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const v=({icons:e={},nameAttr:a="data-lucide",attrs:t={}}={})=>{if(!Object.values(e).length)throw new Error(`Please provide an icons object.
If you want to use all the icons you can import it like:
 \`import { createIcons, icons } from 'lucide';
lucide.createIcons({icons});\``);if(typeof document>"u")throw new Error("`createIcons()` only works in a browser environment.");const r=document.querySelectorAll(`[${a}]`);if(Array.from(r).forEach(n=>h(n,{nameAttr:a,icons:e,attrs:t})),a==="data-lucide"){const n=document.querySelectorAll("[icon-name]");n.length>0&&(console.warn("[Lucide] Some icons were found with the now deprecated icon-name attribute. These will still be replaced for backwards compatibility, but will no longer be supported in v1.0 and you should switch to data-lucide"),Array.from(n).forEach(s=>h(s,{nameAttr:"icon-name",icons:e,attrs:t})))}},f={ArrowUpRight:T,Download:q,MapPin:V,Sparkles:G,TrendingUp:J,MonitorCog:F,UsersRound:K,Handshake:H,FileCheck2:P,ChartNoAxesCombined:N,MessagesSquare:D,GraduationCap:I,Mail:B,MessageCircle:z,Linkedin:R,ArrowUp:$,Menu:U,X:W,ChevronDown:O},X=[{period:"Mei 2023 — Juni 2026",company:"PT. Wismilak Inti Makmur Tbk",role:"Retail Trade Salesman",initial:"W",type:"sales",category:"Sales & Distribution",details:["Mengelola distribusi produk retail untuk memastikan ketersediaan dan visibilitas produk di outlet.","Membangun hubungan bisnis dengan ratusan pemilik toko dan retailer untuk menjaga pertumbuhan pasar.","Mencapai target penjualan bulanan melalui strategi kunjungan yang efektif dan pemantauan stok.","Menganalisis kompetitor dan tren pasar sebagai masukan strategis bagi tim pemasaran."]},{period:"Juni 2022 — Apr 2023",company:"PT. Sinar Sosro",role:"Sales Supervisor",initial:"S",type:"sales",category:"Sales & Leadership",details:["Memimpin dan memotivasi tim sales untuk mencapai target tahunan di wilayah KP. PSP.","Mengelola stok mitra agar ketersediaan produk di pasar tetap stabil.","Mengembangkan area penjualan baru melalui pemetaan outlet.","Menyelesaikan masalah operasional lapangan untuk menjaga produktivitas tim."]},{period:"2021 — 2022",company:"CV. Mitra Cahaya Nauli",role:"Sales Taking Order · Sibolga",initial:"M",type:"sales",category:"Sales & Relationship",details:["Mengelola hubungan dengan outlet yang sudah ada serta mengakuisisi outlet baru.","Memastikan pemesanan barang akurat dan proses pengiriman tepat waktu."]},{period:"2019 — 2020",company:"PT. CNS SBO (Mayora)",role:"Sales Canvas · Siborong-Borong",initial:"C",type:"sales",category:"Sales & Expansion",details:["Melakukan penetrasi pasar secara langsung untuk meningkatkan volume penjualan produk.","Menganalisis kebutuhan pelanggan di lapangan untuk mengoptimalkan strategi penjualan harian."]},{period:"2013 — 2017",company:"Ganesha Operation",role:"IT Staff · Sibolga",initial:"G",type:"it",category:"IT & Technical Support",details:["Memelihara dan memperbaiki perangkat keras serta infrastruktur jaringan komputer.","Mengelola perangkat virtual dan menjaga kelancaran operasional sistem internal.","Mendukung aktivitas marketing online melalui optimasi perangkat dan platform digital."]},{period:"2012 — 2013",company:"METRO Credit/Cash",role:"Collector · Sibolga",initial:"M",type:"sales",category:"Customer Relations",details:["Mengelola penagihan angsuran kredit barang.","Menangani akun tertunda dengan pendekatan komunikasi yang persuasif."]}],M=document.querySelector("#experience-list");function k(e="all"){M.innerHTML=X.map((a,t)=>({job:a,i:t})).filter(({job:a})=>e==="all"||a.type===e).map(({job:a,i:t})=>`<article class="job ${t===0?"open":""}"><button class="job-summary" aria-expanded="${t===0}" aria-controls="job-${t}"><span class="job-period">${a.period}</span><span class="job-logo" aria-hidden="true">${a.initial}</span><div class="job-title"><h3>${a.company}</h3><p>${a.role}</p></div><div class="job-end"><span class="job-category">${a.category}</span><i data-lucide="chevron-down"></i></div></button><div class="job-details" id="job-${t}" ${t===0?"":"hidden"}><ul>${a.details.map(r=>`<li>${r}</li>`).join("")}</ul></div></article>`).join(""),v({icons:f})}k();M.addEventListener("click",e=>{const a=e.target.closest(".job-summary");if(!a)return;const t=a.getAttribute("aria-expanded")==="true";a.setAttribute("aria-expanded",String(!t)),a.closest(".job").classList.toggle("open",!t),document.getElementById(a.getAttribute("aria-controls")).hidden=t});document.querySelectorAll("[data-filter]").forEach(e=>e.addEventListener("click",()=>{document.querySelectorAll("[data-filter]").forEach(a=>{a.classList.toggle("selected",a===e),a.setAttribute("aria-pressed",String(a===e))}),k(e.dataset.filter)}));const l=document.querySelector(".menu-toggle"),c=document.querySelector("nav");function d(e){c.classList.toggle("visible",e),l.setAttribute("aria-expanded",String(e)),l.setAttribute("aria-label",e?"Tutup navigasi":"Buka navigasi"),l.innerHTML=`<i data-lucide="${e?"x":"menu"}"></i>`,v({icons:f})}l.addEventListener("click",()=>d(l.getAttribute("aria-expanded")!=="true"));c.querySelectorAll("a").forEach(e=>e.addEventListener("click",()=>d(!1)));document.addEventListener("keydown",e=>{e.key==="Escape"&&d(!1)});const Y=[...document.querySelectorAll("section[id]")],Z=new IntersectionObserver(e=>{for(const a of e)a.isIntersecting&&c.querySelectorAll("a").forEach(t=>t.classList.toggle("active",t.hash==="#"+a.target.id))},{rootMargin:"-15% 0px -65% 0px",threshold:0});Y.forEach(e=>Z.observe(e));document.querySelector("#year").textContent=new Date().getFullYear();
