<?php
require_once __DIR__ . '/auth.php';
if ($_SERVER['REQUEST_METHOD'] !== 'GET') api_fail('Method tidak diizinkan.',405);
$rows=[];
$stmt=$conn->prepare("SELECT id,'CUSTOMER' jenis,jenis_request,status_approval,tanggal_request,processed_by,processed_at,approval_note FROM pengajuan_sales WHERE sales_email=? UNION ALL SELECT id,'GSP' jenis,jenis_request,status_approval,tanggal_request,processed_by,processed_at,approval_note FROM pengajuan_gsp WHERE sales_email=? ORDER BY tanggal_request DESC LIMIT 100");
$stmt->bind_param('ss',$api_user['email'],$api_user['email']);$stmt->execute();$result=$stmt->get_result();while($r=$result->fetch_assoc())$rows[]=$r;
echo json_encode(['success'=>true,'data'=>$rows],JSON_UNESCAPED_UNICODE);
