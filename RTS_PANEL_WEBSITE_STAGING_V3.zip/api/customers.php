<?php
require_once __DIR__ . '/auth.php';
if ($_SERVER['REQUEST_METHOD'] !== 'GET') api_fail('Method tidak diizinkan.', 405);
$q = trim($_GET['q'] ?? ''); $tipe = strtoupper(trim($_GET['tipe'] ?? '')); $limit = min(100, max(1, (int)($_GET['limit'] ?? 25))); $offset = max(0, (int)($_GET['offset'] ?? 0));
$where = []; $params = []; $types = '';
if ($q !== '') { $where[] = '(nama_toko LIKE ? OR id_customer LIKE ? OR salesman LIKE ?)'; $like="%$q%"; array_push($params,$like,$like,$like); $types.='sss'; }
if (in_array($tipe,['REGULER','GSP'],true)) { $where[]='tipe_customer=?'; $params[]=$tipe; $types.='s'; }
$role = strtoupper($api_user['role']);
if (!in_array($role, ['ADMIN','ASS','WSS','SMST'], true)) { $where[]='salesman=?'; $params[]=$api_user['salesman']; $types.='s'; }
$sql='SELECT id_customer,nama_toko,tipe_customer,salesman,sales_district,alamat,kunjungan,hari,latitude,longitude,status_aktif FROM master_toko'.($where?' WHERE '.implode(' AND ',$where):'').' ORDER BY nama_toko LIMIT ? OFFSET ?';
$stmt=$conn->prepare($sql); $params[]=$limit; $params[]=$offset; $types.='ii'; $stmt->bind_param($types,...$params); $stmt->execute(); $rows=[]; $result=$stmt->get_result(); while($row=$result->fetch_assoc()) $rows[]=$row;
echo json_encode(['success'=>true,'data'=>$rows,'pagination'=>['limit'=>$limit,'offset'=>$offset]],JSON_UNESCAPED_UNICODE);
