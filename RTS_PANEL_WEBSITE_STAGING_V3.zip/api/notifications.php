<?php
require_once __DIR__ . '/auth.php';
if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    $stmt = $conn->prepare('SELECT id,title,message,type,reference_type,reference_id,is_read,created_at FROM notifications WHERE recipient_email=? ORDER BY created_at DESC LIMIT 100');
    $stmt->bind_param('s', $api_user['email']); $stmt->execute(); $rows=[]; $result=$stmt->get_result(); while($row=$result->fetch_assoc()) $rows[]=$row;
    echo json_encode(['success'=>true,'data'=>$rows], JSON_UNESCAPED_UNICODE); exit;
}
if ($_SERVER['REQUEST_METHOD'] === 'PATCH' || $_SERVER['REQUEST_METHOD'] === 'POST') {
    $body=json_decode(file_get_contents('php://input'),true) ?: $_POST; $id=(int)($body['id']??0);
    if ($id < 1) api_fail('ID notifikasi tidak valid.',400);
    $stmt=$conn->prepare('UPDATE notifications SET is_read=1 WHERE id=? AND recipient_email=?'); $stmt->bind_param('is',$id,$api_user['email']); $stmt->execute();
    echo json_encode(['success'=>true,'message'=>'Notifikasi ditandai sudah dibaca.'],JSON_UNESCAPED_UNICODE); exit;
}
api_fail('Method tidak diizinkan.',405);
