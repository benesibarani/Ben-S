<?php
require_once __DIR__ . '/../config.php';
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');
function api_fail(string $message, int $status = 401): never { http_response_code($status); echo json_encode(['success'=>false,'message'=>$message], JSON_UNESCAPED_UNICODE); exit; }
$header = $_SERVER['HTTP_AUTHORIZATION'] ?? '';
if (!preg_match('/^Bearer\s+(.+)$/i', $header, $match)) api_fail('Token tidak ditemukan.');
$hash = hash('sha256', trim($match[1]));
$stmt = $conn->prepare('SELECT t.id token_id, u.id, u.username, u.nama_lengkap, u.email, u.role, u.salesman, u.sales_district, u.status_aktif FROM api_tokens t JOIN sales_users u ON u.id=t.user_id WHERE t.token_hash=? AND t.expires_at > NOW() LIMIT 1');
$stmt->bind_param('s', $hash); $stmt->execute(); $api_user = $stmt->get_result()->fetch_assoc();
if (!$api_user || ($api_user['status_aktif'] ?? 'Aktif') !== 'Aktif') api_fail('Token tidak valid atau sudah kedaluwarsa.');
$touch = $conn->prepare('UPDATE api_tokens SET last_used_at=NOW() WHERE id=?'); $touch->bind_param('i', $api_user['token_id']); $touch->execute();
