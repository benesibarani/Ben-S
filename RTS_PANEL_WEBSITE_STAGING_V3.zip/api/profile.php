<?php
require_once __DIR__ . '/auth.php';
echo json_encode(['success'=>true,'data'=>['id'=>$api_user['id'],'username'=>$api_user['username'],'name'=>$api_user['nama_lengkap'],'email'=>$api_user['email'],'role'=>strtoupper($api_user['role']),'salesman'=>$api_user['salesman'],'sales_district'=>$api_user['sales_district']]],JSON_UNESCAPED_UNICODE);
